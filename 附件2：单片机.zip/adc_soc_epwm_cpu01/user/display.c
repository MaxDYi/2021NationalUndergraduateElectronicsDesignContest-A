/*
 * display.c
 *
 *  Created on: 2021��11��8��
 *      Author: kurui
 */
#include "display.h"
#include "F28x_Project.h"
#include "stdio.h"
#include "math.h"
#include "adc_fft.h"

extern double THD_his[HIS_LENGTH];
extern double Uo[5];
extern double THD;
extern Uint32 InputFreq; //�����źŵ�Ƶ��
extern double Uo_his[5][HIS_LENGTH];

double Uo_Send[5];

#define SCI_IT_MODE 1 //SCI�����жϷ�ʽ�շ�

#define WAVE_LENGTH 300

//Uint16 TX_Buffer[200];
char TX_Buffer_8bit[450];

Uint16 HMI_Rxdata[10]; // Received data for SCI-C
Uint16 HMI_data;       //HMI����������
//Uint16 sdataA[2];    // Send data for SCI-A
//Uint16 rdata_pointA; // Used for checking the received data

char Wave_Send[WAVE_LENGTH];

void getWave(void)
{
    int i, j;
    float Wave[WAVE_LENGTH];

    float max = 0;
    float min = 2 << 15;
    for (i = 0; i < WAVE_LENGTH; i++)
    {
        Wave[i] = 0;
        for (j = 0; j < 5; j++)
        {
            Wave[i] = Wave[i] + Uo_Send[j] * sin(1.0 * i * (j + 1) / WAVE_LENGTH * 2 * 3.141592653);
        }
        if (max < Wave[i])
        {
            max = Wave[i];
        }
        if (min > Wave[i])
        {
            min = Wave[i];
        }
    }
    for (i = 0; i < WAVE_LENGTH; i++)
    {
        Wave_Send[i] = (int)((Wave[i] - min) / (max - min) * 255 + 0.5);
    }
}

void Send_BT(void)
{
    int i;

    TX_Buffer_8bit[0] = 0XAA;
    TX_Buffer_8bit[1] = 0x55;
    TX_Buffer_8bit[2] = (unsigned char)(THD * 100 + 0.5);
    for (i = 0; i < 300; i++)
    {
        TX_Buffer_8bit[i + 3] = Wave_Send[i];
    }

    Uint32 WaveFreq_32bit = (Uint32)(InputFreq / 1000.0 * 255);
    TX_Buffer_8bit[306] = WaveFreq_32bit >> 24;
    TX_Buffer_8bit[305] = WaveFreq_32bit >> 16;
    TX_Buffer_8bit[304] = WaveFreq_32bit >> 8;
    TX_Buffer_8bit[303] = WaveFreq_32bit & 0x00ff;

    TX_Buffer_8bit[307] = 255;
    for (i = 1; i < 5; i++)
    {
        if (Uo[i] < Uo[0])
        {
            TX_Buffer_8bit[307 + i] = (Uint16)(Uo_Send[i] * 255.0 + 0.5);
        }
        else
        {
            TX_Buffer_8bit[307 + i] = 0;
        }
    }
    for (i = 0; i < 5; i++)
    {
        TX_Buffer_8bit[312 + i] = 0;
    }

    TX_Buffer_8bit[317] = 0X55;
    TX_Buffer_8bit[318] = 0XAA;

    for (i = 0; i < 319; i++)
    {
        //Uint16 sendByte = TX_Buffer_8bit[i] * 256 + TX_Buffer_8bit[i + 1];
        scib_xmit(TX_Buffer_8bit[i]);
    }
}

void Send_HMI(void)
{
    int i, j;
    char TxBuf[20];
    char test[10];
    test[0] = THD * 100 + 0.5;
    test[1] = 100;
    for (i = 0; i < 4; i++)
    {
        test[i + 2] = Uo_Send[i+1] * 100 + 0.5;
        if (test[i + 2] > 100)
        {
            test[i + 2] = 100;
        }
    }
    for (j = 0; j < 6; j++)
    {
        //test[j + 2] = Uo[j + 1] / Uo[0] * 100;

        sprintf(TxBuf, "x_U%d.val=%d\xff\xff\xff\xff", j, test[j]);
        scic_msg(TxBuf);
        //        for(i=0;i<3;i++)
        //        {
        //           TxBuf[i]=0xffff;
        //           scic_xmit(TxBuf[i]);
        //        }
    }

    for (j = 0; j < WAVE_LENGTH; j++)
    {
        //value_test[j] = j;
        sprintf(TxBuf, "add 2,0,%d\xff\xff\xff\xff", Wave_Send[j]);
        scic_msg(TxBuf);
    }
}

void send_data(void)
{
    int i, j;
    /*
    for (j = 0; j < HIS_LENGTH - 1; j++)
    {
        for (i = 0; i < HIS_LENGTH - j - 1; i++)
        {
            if (THD_his[i] > THD_his[i + 1])
            {
                double t = THD_his[i];
                THD_his[i] = THD_his[i + 1];
                THD_his[i + 1] = t;
            }
        }
    }*/

    for (i = 0; i < 5; i++)
    {
        double Uo_sum = 0;
        for (j = 0; j < HIS_LENGTH; j++)
        {
            Uo_sum = Uo_sum + Uo_his[i][j];
        }
        Uo[i] = Uo_sum / HIS_LENGTH;
    }

    for (i = 0; i < 5; i++)
    {
        Uo_Send[i] = Uo[i] / Uo[0];
    }

    getWave();


    /*
    double sum = 0;
    for (i = 30; i < HIS_LENGTH - 20; i++)
    {
        sum = sum + THD_his[i];
    }
    THD = sum / 50.0;*/



    double correct[5];
    if (InputFreq <= 1000){         //С��1kHz
            correct[0]=1;
            correct[1]=0.985;
            correct[2]=0.970;
            correct[3]=0.965;
            correct[4]=0.960;
        }
    else if (InputFreq <= 10000){   //1kHz~10kHz
        correct[0]=1;
        correct[1]=0.99;
        correct[2]=0.98;
        correct[3]=0.975;
        correct[4]=0.967;
    }
    else if (InputFreq <= 20000)    //10kHz~20kHz
    {
        correct[0]=1;
        correct[1]=0.985;
        correct[2]=0.985;
        correct[3]=0.985;
        correct[4]=0.985;
    }
    else if (InputFreq <= 25000)    //20kHz~25kHz
    {
        correct[0]=1;
        correct[1]=1.005;
        correct[2]=1.005;
        correct[3]=1.005;
        correct[4]=1.005;
    }
    else if(InputFreq <= 30000){    //25kHz~30kHz
        correct[0]=1;
        correct[1]=1.015;
        correct[2]=1.015;
        correct[3]=1.02;
        correct[4]=1.03;
        }
    else if(InputFreq <= 40000){    //30kHz~40kHz
        correct[0]=1;
        correct[1]=1.01;
        correct[2]=1.01;
        correct[3]=1.03;
        correct[4]=1.05;
    }
    else if(InputFreq <= 50000){    //40kHz~50kHz
        correct[0]=1;
        correct[1]=1.05;
        correct[2]=1.05;
        correct[3]=1.075;
        correct[4]=1.13;
    }
    else{                           //����50kHz
        correct[0]=1;
        correct[1]=1.10;
        correct[2]=1.10;
        correct[3]=1.15;
        correct[4]=1.2;
    }

    THD = 0;
    for (i = 1; i < 5; i++)
    {
        Uo_Send[i]=Uo_Send[i]*+correct[i];
        if(Uo_Send[i]<0){
            Uo_Send[i]=0;
        }
        THD = THD + pow(Uo_Send[i], 2);
    }
    THD = sqrt(THD) / Uo_Send[0];

    Send_HMI();
    Send_BT();
}
//����ͨ�����SCI�ӿ�
//SCIB-������
//SCIC-HMI��
void init_sci_gpio(void)
{
    /*SCIB������GPIOΪ�����͸��ù���*/ //ע������˿����ŵĸ�����Ҫ�����ݱ��� GPIO Muxed Pins�˿ڸ������ŵĵڼ��ָ��÷�ʽ SCIBΪ2
    //RX--P19
    GPIO_SetupPinMux(19, GPIO_MUX_CPU1, 2);
    GPIO_SetupPinOptions(19, GPIO_INPUT, GPIO_PULLUP);
    //TX--18
    GPIO_SetupPinMux(18, GPIO_MUX_CPU1, 2);
    GPIO_SetupPinOptions(18, GPIO_OUTPUT, GPIO_ASYNC);
    /*SCIC������GPIOΪ�����͸��ù���*/ //ע������˿����ŵĸ�����Ҫ�����ݱ��� GPIO Muxed Pins�˿ڸ������ŵĵڼ��ָ��÷�ʽ SCIcΪ6
    //RX--P139
    GPIO_SetupPinMux(139, GPIO_MUX_CPU1, 6);
    GPIO_SetupPinOptions(139, GPIO_INPUT, GPIO_PULLUP);
    //TX--P56
    GPIO_SetupPinMux(56, GPIO_MUX_CPU1, 6);
    GPIO_SetupPinOptions(56, GPIO_OUTPUT, GPIO_ASYNC);
}

//������·SCI�ӿ�
void config_scib_scic(void)
{
    char *msg;
    scib_fifo_init(); // Initialize the SCI FIFO
    scic_fifo_init(); // Initialize the SCI FIFO
#ifdef SCI_IT_MODE    //�жϷ�ʽ�շ�����SCI

#else //������ʽ�շ�����SCI
    scib_echoback_init(); // Initialize SCI for echoback
    scic_echoback_init(); // Initialize SCI for echoback
#endif
    msg = "\r\n\n\nHello World!\0";
    //scib_msg(msg);
    //scic_msg(msg);

    msg = "\r\nTHD meter! \n\0";
    //scib_msg(msg);
    //scic_msg(msg);
}

//
//  scia_echoback_init - Test 1,SCIA  DLB, 8-bit word, baud rate 0x000F,
//                       default, 1 STOP bit, no parity
//
void scib_echoback_init()
{
    Uint16 baud;
    //
    // Note: Clocks were turned on to the scib peripheral
    // in the InitSysCtrl() function
    //

    ScibRegs.SCICCR.all = 0x0007;  // 1 stop bit,  No loopback
                                   // No parity,8 char bits,
                                   // async mode, idle-line protocol
    ScibRegs.SCICTL1.all = 0x0003; // enable TX, RX, internal SCICLK,
                                   // Disable RX ERR, SLEEP, TXWAKE
    ScibRegs.SCICTL2.all = 0x0003;
    ScibRegs.SCICTL2.bit.TXINTENA = 1;
    ScibRegs.SCICTL2.bit.RXBKINTENA = 1;

    //
    // scib at 9600 baud
    // @LSPCLK = 50 MHz (200 MHz SYSCLK) HBAUD = 0x02 and LBAUD = 0x8B.
    // @LSPCLK = 30 MHz (120 MHz SYSCLK) HBAUD = 0x01 and LBAUD = 0x86.
    //
    //    ScibRegs.SCIHBAUD.all = 0x0002;
    //    ScibRegs.SCILBAUD.all = 0x008B;
    baud = 50000000 / (8 * 115200) - 1; //������115200
    ScibRegs.SCIHBAUD.all = baud >> 8;
    ScibRegs.SCILBAUD.all = baud & 0xff;

    ScibRegs.SCICTL1.all = 0x0023; // Relinquish SCI from Reset
}

//
// scib_xmit - Transmit a character from the SCI
//
void scib_xmit(int a)
{
#ifdef SCI_IT_MODE //�жϷ�ʽ�շ�����SCI
    while (ScibRegs.SCICTL2.bit.TXRDY == 0)
    {
    }
    ScibRegs.SCITXBUF.all = a;
#else
    while (ScibRegs.SCIFFTX.bit.TXFFST != 0)
    {
    }
    ScibRegs.SCITXBUF.all = a;
#endif
}

//
// scib_msg - Transmit message via scib
//
void scib_msg(char *msg)
{
    int i;
    i = 0;
    while (msg[i] != '\0')
    {
        scib_xmit(msg[i]);
        i++;
    }
}

//
// scib_fifo_init - Initialize the SCI FIFO
//
void scib_fifo_init()
{

    Uint16 baud1;
    ScibRegs.SCICCR.all = 0x0007;  // 1 stop bit,  No loopback
                                   // No parity,8 char bits,
                                   // async mode, idle-line protocol
    ScibRegs.SCICTL1.all = 0x0003; // enable TX, RX, internal SCICLK,
                                   // Disable RX ERR, SLEEP, TXWAKE
    ScibRegs.SCICTL2.bit.TXINTENA = 1;
    ScibRegs.SCICTL2.bit.RXBKINTENA = 1;
    ScibRegs.SCICCR.bit.LOOPBKENA = 0;   // Enable loop back 1
    baud1 = 50000000 / (8 * 115200) - 1; //������115200
    ScibRegs.SCIHBAUD.all = baud1 >> 8;
    ScibRegs.SCILBAUD.all = baud1 & 0xff;

#ifdef SCI_IT_MODE //�жϷ�ʽ�շ�����SCI
    //SCI����FIFO�Ĵ���SCIFFTX
    ScibRegs.SCIFFTX.bit.TXFFIENA = 0;    //��ʹ�ܷ���FIFO�ж�
    ScibRegs.SCIFFTX.bit.TXFFIL = 0x0C;   //12��FIFOʹ��
    ScibRegs.SCIFFTX.bit.TXFFINTCLR = 1;  //����FIFO�ж������־λ��1�����TXFFINTλ
    ScibRegs.SCIFFTX.bit.TXFIFORESET = 0; //SCI����FIFO��λ��0����λ����FIFOָ��
    //SCI����FIFO�Ĵ���SCIFFRX
    ScibRegs.SCIFFRX.bit.RXFFOVRCLR = 1;  //SCI����FIFO��������־λ��1�����RXFFOVF
    ScibRegs.SCIFFRX.bit.RXFFINTCLR = 1;  //����FIFO�ж������־λ
    ScibRegs.SCIFFRX.bit.RXFIFORESET = 0; //SCI����FIFO��λ��0����λ����FIFOָ��
    ScibRegs.SCIFFRX.bit.RXFFIENA = 1;    //����FIFO�ж�ʹ��λ��
    ScibRegs.SCIFFRX.bit.RXFFIL = 0x0C;   //12��FIFOʹ��

    //            ScibRegs.SCIFFTX.all = 0xC022;
    //            ScibRegs.SCIFFRX.all = 0x0022;//ʹ��FIFO�����ж�
    //            ScibRegs.SCIFFCT.all = 0x00;

    //        ScibRegs.SCIFFTX.all = 0xC03F;
    //        ScibRegs.SCIFFRX.all = 0x0021;//ʹ��FIFO�����ж�
    ScibRegs.SCIFFCT.all = 0x00;
    ScibRegs.SCICTL1.bit.SWRESET = 1; //Relinquish SCI from Reset
#else
    ScibRegs.SCIFFTX.all = 0xE040;
    ScibRegs.SCIFFRX.all = 0x2044;
    ScibRegs.SCIFFCT.all = 0x0;
#endif
}

//
// scicTxFifoIsr - SCIC Transmit FIFO ISR
//
interrupt void scibTxFifoIsr(void)
{
    Uint16 i;

    // ScicRegs.SCIFFTX.bit.TXFFINTCLR=1;   // Clear SCI Interrupt flag
    PieCtrlRegs.PIEACK.all |= 0x080; // Issue PIE ACK
}

//
// scicRxFifoIsr - SCIC Receive FIFO ISR
//
Uint16 rxb_cnt = 0;
interrupt void scibRxFifoIsr(void)
{

    ScicRegs.SCIFFRX.bit.RXFFOVRCLR = 1; // Clear Overflow flag
    ScicRegs.SCIFFRX.bit.RXFFINTCLR = 1; // Clear Interrupt flag

    PieCtrlRegs.PIEACK.all |= 0x080; // Issue PIE ack
}

//
//  scia_echoback_init - Test 1,SCIA  DLB, 8-bit word, baud rate 0x000F,
//                       default, 1 STOP bit, no parity
//
void scic_echoback_init()
{
    Uint16 baud1;
    //
    // Note: Clocks were turned on to the scib peripheral
    // in the InitSysCtrl() function
    //

    ScicRegs.SCICCR.all = 0x0007;  // 1 stop bit,  No loopback
                                   // No parity,8 char bits,
                                   // async mode, idle-line protocol
    ScicRegs.SCICTL1.all = 0x0003; // enable TX, RX, internal SCICLK,
                                   // Disable RX ERR, SLEEP, TXWAKE
    ScicRegs.SCICTL2.all = 0x0003;
    ScicRegs.SCICTL2.bit.TXINTENA = 1;
    ScicRegs.SCICTL2.bit.RXBKINTENA = 1;

    //
    // scic at 9600 baud
    // @LSPCLK = 50 MHz (200 MHz SYSCLK) HBAUD = 0x02 and LBAUD = 0x8B.
    // @LSPCLK = 30 MHz (120 MHz SYSCLK) HBAUD = 0x01 and LBAUD = 0x86.
    //
    //    ScicRegs.SCIHBAUD.all = 0x0002;
    //    ScicRegs.SCILBAUD.all = 0x008B;
    baud1 = 50000000 / (8 * 115200) - 1; //������115200
    ScicRegs.SCIHBAUD.all = baud1 >> 8;
    ScicRegs.SCILBAUD.all = baud1 & 0xff;

    ScicRegs.SCICTL1.all = 0x0023; // Relinquish SCI from Reset
}

//
// scic_xmit - Transmit a character from the SCI
//
void scic_xmit(int a)
{
#ifdef SCI_IT_MODE //
    while (ScicRegs.SCICTL2.bit.TXRDY == 0)
    {
    }
    ScicRegs.SCITXBUF.all = a;
#else
    while (ScicRegs.SCIFFTX.bit.TXFFST != 0)
    {
    }
    ScicRegs.SCITXBUF.all = a;
#endif
}

//
// scic_msg - Transmit message via scic
//
void scic_msg(char *msg)
{
    Uint16 len;
    Uint16 i;
    len = (strlen(msg) - 1);
    for (i = 0; i < len; i++)
    {
        scic_xmit(msg[i]);
    }
}

//
// scic_fifo_init - Initialize the SCI FIFO
//
void scic_fifo_init()
{
    Uint16 baud1;
    ScicRegs.SCICCR.all = 0x0007;  // 1 stop bit,  No loopback
                                   // No parity,8 char bits,
                                   // async mode, idle-line protocol
    ScicRegs.SCICTL1.all = 0x0003; // enable TX, RX, internal SCICLK,
                                   // Disable RX ERR, SLEEP, TXWAKE
    ScicRegs.SCICTL2.bit.TXINTENA = 1;
    ScicRegs.SCICTL2.bit.RXBKINTENA = 1;
    ScicRegs.SCICCR.bit.LOOPBKENA = 0;   // Enable loop back 1
    baud1 = 50000000 / (8 * 115200) - 1; //������115200
    ScicRegs.SCIHBAUD.all = baud1 >> 8;
    ScicRegs.SCILBAUD.all = baud1 & 0xff;

#ifdef SCI_IT_MODE //�жϷ�ʽ�շ�����SCI
    //SCI����FIFO�Ĵ���SCIFFTX
    ScicRegs.SCIFFTX.bit.TXFFIENA = 0;    //��ʹ�ܷ���FIFO�ж�
    ScicRegs.SCIFFTX.bit.TXFFIL = 0x0C;   //12��FIFOʹ��
    ScicRegs.SCIFFTX.bit.TXFFINTCLR = 1;  //����FIFO�ж������־λ��1�����TXFFINTλ
    ScicRegs.SCIFFTX.bit.TXFIFORESET = 0; //SCI����FIFO��λ��0����λ����FIFOָ��
    //SCI����FIFO�Ĵ���SCIFFRX
    ScicRegs.SCIFFRX.bit.RXFFOVRCLR = 1;  //SCI����FIFO��������־λ��1�����RXFFOVF
    ScicRegs.SCIFFRX.bit.RXFFINTCLR = 1;  //����FIFO�ж������־λ
    ScicRegs.SCIFFRX.bit.RXFIFORESET = 0; //SCI����FIFO��λ��0����λ����FIFOָ��
    ScicRegs.SCIFFRX.bit.RXFFIENA = 1;    //����FIFO�ж�ʹ��λ��
    ScicRegs.SCIFFRX.bit.RXFFIL = 0x0C;   //12��FIFOʹ��

    //            ScicRegs.SCIFFTX.all = 0xC022;
    //            ScicRegs.SCIFFRX.all = 0x0022;//ʹ��FIFO�����ж�
    //            ScicRegs.SCIFFCT.all = 0x00;

    //        ScicRegs.SCIFFTX.all = 0xC03F;
    //        ScicRegs.SCIFFRX.all = 0x0021;//ʹ��FIFO�����ж�
    ScicRegs.SCIFFCT.all = 0x00;
    ScicRegs.SCICTL1.bit.SWRESET = 1; //Relinquish SCI from Reset
#else
    ScicRegs.SCIFFTX.all = 0xE040;
    ScicRegs.SCIFFRX.all = 0x2044;
    ScicRegs.SCIFFCT.all = 0x0;
#endif

    ScicRegs.SCICTL1.all = 0x0023; // Relinquish SCI from Reset
    ScicRegs.SCIFFTX.bit.TXFIFORESET = 1;
    ScicRegs.SCIFFRX.bit.RXFIFORESET = 1;
}

//
// scicTxFifoIsr - SCIC Transmit FIFO ISR
//
interrupt void scicTxFifoIsr(void)
{
    Uint16 i;
    //
    //    for(i=0; i< 2; i++)
    //    {
    //       ScicRegs.SCITXBUF.all=sdataA[i];  // Send data
    //    }

    // ScicRegs.SCIFFTX.bit.TXFFINTCLR=1;   // Clear SCI Interrupt flag
    PieCtrlRegs.PIEACK.all |= 0x080; // Issue PIE ACK
}

//
// scicRxFifoIsr - SCIC Receive FIFO ISR
//
Uint16 rx_cnt = 0;
interrupt void scicRxFifoIsr(void)
{
    Uint16 i;
    HMI_Rxdata[rx_cnt] = ScicRegs.SCIRXBUF.all; // Read data
                                                //ͨ��Э�� 0xaa 0x55 data1 data2 0x55 0xaa
    if ((HMI_Rxdata[rx_cnt - 5] == 0xaa) & (HMI_Rxdata[rx_cnt - 4] == 0x55) & (HMI_Rxdata[rx_cnt - 1] == 0x55) & (HMI_Rxdata[rx_cnt] == 0xaa))
    {
        HMI_data = (HMI_Rxdata[rx_cnt - 3] << 8) + HMI_Rxdata[rx_cnt - 2]; //
        rx_cnt = 0;
    }
    else
        rx_cnt++;
    if (rx_cnt > 10)
    {
        rx_cnt = 0;
    }

    ScicRegs.SCIFFRX.bit.RXFFOVRCLR = 1; // Clear Overflow flag
    ScicRegs.SCIFFRX.bit.RXFFINTCLR = 1; // Clear Interrupt flag

    PieCtrlRegs.PIEACK.all |= 0x080; // Issue PIE ack
}
