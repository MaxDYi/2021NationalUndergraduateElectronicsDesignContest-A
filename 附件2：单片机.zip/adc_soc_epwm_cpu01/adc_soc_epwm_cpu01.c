//###########################################################################
//
// FILE:   adc_soc_epwm_cpu01.c
//
// TITLE:  ADC triggering via epwm for F2837xD.
//
//! \addtogroup cpu01_example_list
//! <h1> ADC ePWM Triggering (adc_soc_epwm)</h1>
//!
//! This example sets up the ePWM to periodically trigger the ADC.
//!
//! After the program runs, the memory will contain:\n
//! - \b AdcaResults \b: A sequence of analog-to-digital conversion samples from
//! pin A0. The time between samples is determined based on the period
//! of the ePWM timer.
//
//###########################################################################
// $TI Release: F2837xD Support Library v210 $
// $Release Date: Tue Nov  1 14:46:15 CDT 2016 $
// $Copyright: Copyright (C) 2013-2016 Texas Instruments Incorporated -
//             http://www.ti.com/ ALL RIGHTS RESERVED $
//###########################################################################

//
// Included Files
//
#include "F28x_Project.h"
#include "math.h"
#include "fpu_rfft.h"
#include "stdio.h"
#include "adc_fft.h"
#include "display.h"
#include "Example_freqcal.h"

// Function Prototypes
//
FREQCAL freq_test = FREQCAL_DEFAULTS;
//SPI��غ���
void delay_loop(void);

__interrupt void ecap1_isr(void);
void InitECapture(void);
__interrupt void cpu_timer0_isr(void); //timer0 �жϷ�����
// Defines
//

//#define RESULTS_BUFFER_SIZE 1024
#define ADC_TOGGLE_GPIO 52
#define BLINKY_LED_GPIO 31

//
// Globals
//

Uint32 LoopCnt = 0;       //��ѭ����������
Uint16 SecNum = 0;        //���ϵ翪ʼ�����
Uint16 half_Sec_flag = 0; //�����־λ
Uint16 Sec_flag = 0;      //���־λ
Uint16 sdata;             // send data
Uint16 rdata;             // received data
Uint16 spi_rx_flag = 0;   //����SPI�ܷ���յ����� ����ѭ���н��յ�0x55����Ϊ1

Uint32 InputFreq; //�����źŵ�Ƶ��
double Uo[5];
//#pragma DATA_SECTION (Uo_his, "UO_POS");
double Uo_his[5][HIS_LENGTH];
double THD = 0; //THD������

Uint32 AdcCapRate = 20000 * 20.48;

/*��FLASH������*/
extern Uint16 RamfuncsLoadStart;
extern Uint16 RamfuncsLoadEnd;
extern Uint16 RamfuncsRunStart;

void MemCopy(Uint16 *SourceAddr, Uint16 *SourceEndAddr, Uint16 *DestAddr)
{
    while (SourceAddr < SourceEndAddr)
    {
        *DestAddr++ = *SourceAddr++;
    }
    return;
}

void main(void)
{
    MemCopy(&RamfuncsLoadStart, &RamfuncsLoadEnd, &RamfuncsRunStart);
    InitFlash();
    //

    // Step 1. Initialize System Control:
    // PLL, WatchDog, enable Peripheral Clocks
    // This example function is found in the F2837xD_SysCtrl.c file.
    //

    InitSysCtrl();
    //
    // Step 2. Initialize GPIO:
    // This example function is found in the F2837xD_Gpio.c file and
    // illustrates how to set the GPIO to it's default state.
    //
    InitGpio(); // Skipped for this example
    GPIO_SetupPinMux(ADC_TOGGLE_GPIO, GPIO_MUX_CPU1, 0);
    GPIO_SetupPinOptions(ADC_TOGGLE_GPIO, GPIO_OUTPUT, GPIO_PUSHPULL);

    GPIO_SetupPinMux(BLINKY_LED_GPIO, GPIO_MUX_CPU1, 0);
    GPIO_SetupPinOptions(BLINKY_LED_GPIO, GPIO_OUTPUT, GPIO_PUSHPULL);

    /*
    InitSpiaGpio();
    InitSpibGpio2(); //����SPI B
*/

    InitECap1Gpio(67); //����67��Ϊcap�����Ƶ
    GPIO_SetupPinOptions(67, GPIO_INPUT, GPIO_ASYNC);
    InitEQep1Gpio(); //����EQEPģ���Ƶ

    init_sci_gpio(); //����SCIB SCIC�˿�
    //
    // Step 3. Clear all interrupts and initialize PIE vector table:
    // Disable CPU interrupts
    //
    DINT;

    //
    // Initialize the PIE control registers to their default state.
    // The default state is all PIE interrupts disabled and flags
    // are cleared.
    // This function is found in the F2837xD_PieCtrl.c file.
    //
    InitPieCtrl();

    //
    // Disable CPU interrupts and clear all CPU interrupt flags:
    //
    IER = 0x0000;
    IFR = 0x0000;

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    // This will populate the entire table, even if the interrupt
    // is not used in this example.  This is useful for debug purposes.
    // The shell ISR routines are found in F2837xD_DefaultIsr.c.
    // This function is found in F2837xD_PieVect.c.
    //
    InitPieVectTable();
    /*    InitSpi();
    InitSpib();      // Initialize the SPI b
    spi_fifo_init(); // Initialize the SPI FIFO
    sdata = 0x0000;*/
    //
    // Map ISR functions
    //
    EALLOW;
    PieVectTable.ADCA1_INT = &adca1_isr; //function for ADCA interrupt 1
    //PieVectTable.ECAP1_INT = &ecap1_isr; //CAP�ж�
    PieVectTable.TIMER0_INT = &cpu_timer0_isr; //timer0�ж�
    PieVectTable.SCIB_RX_INT = &scicRxFifoIsr;
    PieVectTable.SCIB_TX_INT = &scicTxFifoIsr;
    PieVectTable.SCIC_RX_INT = &scicRxFifoIsr;
    PieVectTable.SCIC_TX_INT = &scicTxFifoIsr;
    PieVectTable.EPWM1_INT = &prdTick; //��Ƶ��PWM�ж�
    EDIS;

    //
    // Configure the ADC and power it up
    //
    ConfigureADC();
    EPwmSetup(); //��Ƶ��pwm
    //
    // Configure the ePWM
    //
    ConfigureEPWM();
    //
    // Setup the ADC for ePWM triggered conversions on channel 0
    //
    SetupADCEpwm(0);
    //InitECapture();//��ʼ��CAPģ�� ��Ƶ��
    UserConfigureEPWM(AdcCapRate); //��ʼ��������

    InitCpuTimers();
    // Configure CPU-Timer 0 to __interrupt every 500 milliseconds:
    // 60MHz CPU Freq, 50 millisecond Period (in uSeconds)
    ConfigCpuTimer(&CpuTimer0, 200, 500000);
    CpuTimer0Regs.TCR.all = 0x4001;
    config_scib_scic(); //������·SCI
                        // Enable global Interrupts and higher priority real-time debug events:
                        //
    IER |= M_INT1;      //Enable group 1 interrupts
    IER |= M_INT3;
    //IER |= M_INT4;
    IER |= M_INT8;
    IER |= M_INT9;
    //
    // enable PIE interrupt
    //
    PieCtrlRegs.PIEIER1.bit.INTx1 = 1;
    PieCtrlRegs.PIEIER3.bit.INTx1 = 1;
    //PieCtrlRegs.PIEIER4.bit.INTx1 = 1;
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;
    PieCtrlRegs.PIEIER8.bit.INTx5 = 1; //SCIC Receive Interrupt PIE Group 8, INT5
    PieCtrlRegs.PIEIER8.bit.INTx6 = 1; //SCIC Transmit Interrupt PIE Group 8, INT6
    PieCtrlRegs.PIEIER9.bit.INTx3 = 1; //SCIB Transmit Interrupt
    PieCtrlRegs.PIEIER9.bit.INTx4 = 1; //SCIB Transmit Interrupt
                                       //  IER = 0x100;
    EINT;                              // Enable Global interrupt INTM
    ERTM;                              // Enable Global realtime interrupt DBGM

    //
    // sync ePWM
    //
    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;
    GPIO_WritePin(BLINKY_LED_GPIO, 1); //Ϩ����ɫLED

    //
    // Initializes eQEP for frequency calculation in
    // FREQCAL_Init(void)function in Example_EPwmSetup.c
    freq_test.init(&freq_test);

    //
    //take conversions indefinitely in loop
    //
    EPwm2Regs.ETSEL.bit.SOCAEN = 1;  //enable SOCA
    EPwm2Regs.TBCTL.bit.CTRMODE = 0; //unfreeze, and enter up count mode
    rfft_init();                     //��һ�γ�ʼ��RFFT

   // scic_msg("while(1)begin\r\n");
    do
    {
        LoopCnt++;

        //scic_msg("loop\r\n");
        //while(flagInputReady == 0){};
        if (flagInputReady == 1) //ADC������ɣ���ֹͣ�ɼ�������FFT����
        {
            //scic_msg("adc over\r\n");


            THD_cal();          //����FFT ����THD
            //scic_msg("thd over\r\n");
            flagInputReady = 0; //�����־λ
            //
            //start ePWM
            //
            EPwm2Regs.ETSEL.bit.SOCAEN = 1;  //enable SOCA
            EPwm2Regs.TBCTL.bit.CTRMODE = 0; //unfreeze, and enter up count mode

            rfft_init();
            //scic_msg("fft over\r\n");
        }

        if (Sec_flag == 1) //ÿ1s���¼�
        {
            //scic_msg("led over\r\n");
            GPIO_WritePin(BLINKY_LED_GPIO, 0); //����
            send_data();
            GPIO_WritePin(BLINKY_LED_GPIO, 1); //���
            Sec_flag = 0;                      //�����־λ
        }
    } while (1);
}

//
// error - Error function that halts the debugger
//
void error(void)
{
    scic_msg("error\r\n");
    asm("     ESTOP0"); // Test failed!! Stop!
    for (;;)
        ;
}


//
// cpu_timer0_isr - CPU Timer0 ISR that toggles GPIO32 once per 500ms
//
__interrupt void cpu_timer0_isr(void)
{
    CpuTimer0.InterruptCount++;
    SecNum++; //������ۼ�
    if (SecNum % 1 == 0)
    {
        half_Sec_flag = 1;
    }
    if (SecNum % 2 == 0)
    {
        Sec_flag = 1;
    }
    //GpioDataRegs.GPBTOGGLE.bit.GPIO31 = 1;//����

    //
    // Acknowledge this __interrupt to receive more __interrupts from group 1
    //
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}

//
// prdTick - Interrupts once per ePWM period
//

__interrupt void prdTick(void)
{
    //
    // Checks for event and calculates frequency in FREQCAL_Calc(FREQCAL *p)
    // function in Example_EPwmSetup.c
    //
    freq_test.calc(&freq_test);

    //
    // Acknowledge this __interrupt to receive more __interrupts from group 1
    //
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
    EPwm1Regs.ETCLR.bit.INT = 1;
}

//
// End of file
//
