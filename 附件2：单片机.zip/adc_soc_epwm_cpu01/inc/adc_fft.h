/*
 * @Descripttion: 
 * @version: 
 * @Author: MDYi
 * @Date: 2021-11-11 13:41:10
 * @LastEditTime: 2021-11-12 18:17:36
 */
/*
 * adc_fft.h
 *
 *  Created on: 2021��11��8��
 *      Author: kurui
 */

#ifndef INC_ADC_FFT_H_
#define INC_ADC_FFT_H_

#define HIS_LENGTH 100

void ConfigureADC(void);
void ConfigureEPWM(void);
void SetupADCEpwm(Uint16 channel);
interrupt void adca1_isr(void);

//THD��غ���

void rfft_init(void);
void THD_cal(void);
void UserConfigureEPWM(Uint32 capreate);
extern double Uo[5];
extern double THD;
extern volatile uint16_t flagInputReady;

#endif /* INC_ADC_FFT_H_ */
