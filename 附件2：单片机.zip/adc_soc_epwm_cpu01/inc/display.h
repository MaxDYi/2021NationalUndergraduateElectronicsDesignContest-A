/*
 * @Descripttion: 
 * @version: 
 * @Author: MDYi
 * @Date: 2021-11-11 13:41:10
 * @LastEditTime: 2021-11-12 18:17:50
 */
/*
 * display.h
 *
 *  Created on: 2021��11��8��
 *      Author: kurui
 */

#ifndef INC_DISPLAY_H_
#define INC_DISPLAY_H_

void send_data(void);
void init_sci_gpio(void);
void config_scib_scic(void);
//SCI��غ���
void scib_echoback_init(void);
void scib_fifo_init(void);
void scib_xmit(int a);
void scib_msg(char *msg);
void scic_echoback_init(void);
void scic_fifo_init(void);
void scic_xmit(int a);
void scic_msg(char *msg);

interrupt void scibTxFifoIsr(void);
interrupt void scibRxFifoIsr(void);
interrupt void scicTxFifoIsr(void);
interrupt void scicRxFifoIsr(void);

#endif /* INC_DISPLAY_H_ */
